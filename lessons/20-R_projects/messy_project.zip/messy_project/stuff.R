# My analysis code, see README for details about project

# Load packages

# Load functions
setwd("Users/dfalster/Dropbox/teaching/myCourses/2016.06.20-projects/projects")
source("Users/dfalster/Dropbox/teaching/myCourses/2016.06.20-projects/projects/functions.R")
source("Users/dfalster/Dropbox/teaching/myCourses/2016.06.20-projects/projects/figures.R")

library(tidyverse)

# Load data
data <- read_csv("Users/dfalster/Dropbox/teaching/myCourses/2016.06.20-projects/seed_root_herbivores.csv", as.is=TRUE)

# Fix, subset and transform data (history of changes to raw data)
data$log_Weight <- log10(data$Weight)
data$log_Height <- log10(data$Height)

# Run analysis
mod <- lm(log_Weight ~ log_Height, data)
summary(mod)

# Save statistical table
write_csv(data.frame(summary(mod)$coefficients), file="stats_table.csv")

# Make figure

pdf("figure1.pdf", 5, 5.5)
make_figure_height(data, mod)
dev.off()

png("figure1.png", 350, 400)
make_figure_height(data, mod)
dev.off()
