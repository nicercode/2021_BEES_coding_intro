# Make figure code

make_figure_height <- function(data, mod){

  log_Height <- sort(data$log_Height)
  pred_log_Weight <- predict(mod, list(log_Height), interval="confidence")

  plot(log_Weight ~ log_Height, data, col="grey", axes=FALSE, xlim=c(1, 2), ylim=c(-1, 2), xlab="Plant height, cm", ylab="Plant weight, g")
  polygon(c(log_Height, rev(log_Height)), c(pred_log_Weight[,"lwr"], rev(pred_log_Weight[,"upr"])), border=NA, col=rgb(0, 0, 0, 0.4))
  lines(log_Height, pred_log_Weight[,"fit"])

  axis(1, at=log10(seq(10, 100, 10)), labels = c(10, 20, NA, NA, 50, NA, NA, NA, NA, 100), las=2)
  axis(2, at=log10(seq(0.1, 1, 0.1)), labels = c(0.1, 0.2, NA, NA, 0.5, NA, NA, NA, NA, NA), las=2)
  axis(2, at=log10(seq(1, 10, 1)), labels = c(1, 2, NA, NA, 5, NA, NA, NA, NA, NA), las=2)
  axis(2, at=log10(seq(10, 100, 10)), labels = c(10, 20, NA, NA, 50, NA, NA, NA, NA, 100), las=2)

}
