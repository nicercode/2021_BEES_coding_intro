# About this project

I first thought about this concept on a fieldtrip in the desert.