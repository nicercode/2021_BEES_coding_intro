# My functions code

standard.error <- function(x) {
  sd(x) / sqrt(length(x))
}
